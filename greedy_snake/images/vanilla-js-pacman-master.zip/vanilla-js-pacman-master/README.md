## Vanilla JS Pacman

The files for the Youtube tutorial on creating a Vanilla JS Pacman game by Weibenfalk.

### How to

Navigate inside the folder marked with "Start Here" and run ```npm install```
Then type ```npm start``` to start up the dev. server. 
